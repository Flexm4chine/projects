//
//  RowTabel.swift
//  WatchWithSwift
//
//  Created by Admin on 23.12.2020.
//

import WatchKit

class RowTabel: NSObject {

    @IBOutlet weak var rowPicture: WKInterfaceImage!
    @IBOutlet weak var rowRecipeName: WKInterfaceLabel!
}
