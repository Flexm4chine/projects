//
//  RecipeDescriptionIC.swift
//  WatchWithSwift
//
//  Created by Admin on 23.12.2020.
//

import WatchKit
import Foundation


class RecipeDescriptionIC: WKInterfaceController {

    @IBOutlet weak var fullRecipeLabel: WKInterfaceLabel!
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        if let context = context as? String {
            fullRecipeLabel.setText(context)
        }

    }



}
