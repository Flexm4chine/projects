////
////  InterfaceController.swift
////  WatchWithSwift WatchKit Extension
////
////  Created by Admin on 23.12.2020.
////
import Foundation
//
import WatchKit
import Foundation
////import UIKit
//
class TabelRecipesIC: WKInterfaceController {

}
//    @IBOutlet weak var tabel: WKInterfaceTable!
//
//    override func awake(withContext context: Any?) {
//        print("\(Recipes.getRecipe().count) kolvo recipes")
//
//        tabel.setNumberOfRows(Recipes.getRecipe().count, withRowType: "tabelRow")
//
//        for (index, item) in Recipes.getRecipe().enumerated(){
//            let controller = tabel.rowController(at: index) as! RowTabel
//            controller.rowRecipeName.setText(item.recipeName)
//            controller.rowPicture.setImageNamed(item.recipeIcon)
//        }
//    }
//
//    override func contextForSegue(withIdentifier segueIdentifier: String, in table: WKInterfaceTable, rowIndex: Int) -> Any? {
//        return Recipes.getRecipe()[rowIndex]
//    }
//
//    override func willActivate() {
//        // This method is called when watch view controller is about to be visible to user
//    }
//
//    override func didDeactivate() {
//        // This method is called when watch view controller is no longer visible
//    }
//
//}
