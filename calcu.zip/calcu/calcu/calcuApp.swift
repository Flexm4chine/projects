//
//  calcuApp.swift
//  calcu
//
//  Created by Admin on 30.10.2020.
//

import SwiftUI

@main
struct calcuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
