//
//  ContentView.swift
//  calcu
//
//  Created by Admin on 30.10.2020.
//

import SwiftUI

struct ContentView: View{
    
    @State var label : String = "0"
    @State var peremennyaOne : Double = 0
    @State var peremennyaTwo : Double = 0
    @State var CurrantDo : String = ""
    @State var Result : Double = 0
   
    @State var isPresset : Bool = false
    
    var body: some View{
        
        ZStack(alignment: .bottom ) {
            
            Color.black.edgesIgnoringSafeArea(.all)
            
            Text(label).foregroundColor(Color(.white))
                .frame(width: 385, height: 150, alignment: .trailing)
                .background(Color(.black))
                .font(.system(size: 70))
                .position(x: 208, y: 240)
            
            VStack(spacing: 20 ){
                HStack(spacing: 20) { // Первая строчка
                    Button(action: {
                        
                        self.isPresset = false
                        self.CurrantDo = ""
                        self.label = "0"
                        self.peremennyaOne = 0
                        self.peremennyaTwo = 0
                        
                        
                    }, label: {Text("AC").foregroundColor(Color(.black))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.gray))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                    Button(action: {
                        
                        var temp = Double(label)!
                        temp = temp * (-1)
                        label = NSNumber(value:temp).stringValue
                        
                    }, label: {Text("+/-").foregroundColor(Color(.black))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.gray))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                    Button(action: {
                        
                        var temp = Double(label)!
                        temp = temp / 100
                        label = NSNumber(value:temp).stringValue
                        
                    }, label: {Text("%").foregroundColor(Color(.black))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.gray))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                    Button(action: {
                            
                        isPresset = true
                        peremennyaOne = Double(label)!
                        label = ""
                        CurrantDo = "/"
                        
                        
                    }, label: {Text("/").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.orange))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                }
                HStack(spacing: 20) { // Вторая строчка
                    Button(action: { if label == "0" || label == ""{
                        label = "7" } else { label = label + "7" }
                     }, label: {Text("7").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.darkGray))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                    Button(action: { if label == "0" || label == "" {
                        label = "8" } else { label = label + "8" }
                     }, label: {Text("8").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.darkGray))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                    Button(action: {
                        if label == "0" || label == ""{
                            label = "9" } else { label = label + "9"}
                    }, label: {Text("9").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.darkGray))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                    Button(action: {
                        
                        isPresset = true
                        peremennyaOne = Double(label)!
                        label = ""
                        CurrantDo = "*"
                        
                    }, label: {Text("x").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.orange))
                        .clipShape(Circle())
                        .font(.system(size: 40))
                }
                HStack(spacing: 20) { // Третья строчка
                    Button(action: {
                        if label == "0" || label == ""{
                            label = "4" } else { label = label + "4"}
                    }, label: {Text("4").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.darkGray))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                    Button(action: {
                        if label == "0" || label == ""{
                            label = "5" } else { label = label + "5"}
                    }, label: {Text("5").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.darkGray))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                    Button(action: {
                        if label == "0" || label == ""{
                            label = "6" } else { label = label + "6"}
                    }, label: {Text("6").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.darkGray))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                    Button(action: {
                        
                        isPresset = true
                        peremennyaOne = Double(label)!
                        label = ""
                        CurrantDo = "-"
                        
                    }, label: {Text("-").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.orange))
                        .clipShape(Circle())
                        .font(.system(size: 40))
                }
                HStack(spacing: 20) { // Четвертая строчка
                    Button(action: {
                        if label == "0" || label == ""{
                            label = "1" } else { label = label + "1"}
                        
                    }, label: {Text("1").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.darkGray))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                    Button(action: {
                        if label == "0" || label == ""{
                        label = "2" } else { label = label + "2"
                            
                        }
                    }, label: {Text("2").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.darkGray))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                    Button(action: { }, label: {Text("3").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.darkGray))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                    Button(action: {
                        
                        isPresset = true
                        peremennyaOne = Double(label)!
                        label = ""
                        CurrantDo = "+"
                        
                        
                    }, label: {Text("+").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.orange))
                        .clipShape(Circle())
                        .font(.system(size: 40))
                 }
                HStack(spacing: 20) { // Пятая строчка
                    Button(action: {
                        if label == "0" || label == ""{
                            label = "0" } else { label = label + "0"}
                        
                    }, label: {Text("0").foregroundColor(Color(.white))})
                        .frame(width: 180, height: 80)
                        .background(Color(.darkGray))
                        .cornerRadius(60)
                        .font(.system(size: 30))
                    Button(action: {
                        if String(label).contains("."){
                            return;
                        }else{
                            label = label + "."
                        }
                    }, label: {Text(",").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.darkGray))
                        .clipShape(Circle())
                        .font(.system(size: 30))
                    Button(action: {
                        
                        
                        
                        if isPresset == true {
                            
                            if !label.isEmpty {
                                switch CurrantDo {
                                case "/":
                                    peremennyaTwo = Double(label)!
                                    let temp : Double = Double(peremennyaOne) / Double(peremennyaTwo)
                                    peremennyaOne = temp
                                    Result = Double(round(100000 * temp)/100000)
                                    isPresset = false
                                    label = NSNumber(value:Result).stringValue
                                    return;
                                case "*":
                                    peremennyaTwo = Double(label)!
                                    let temp : Double = Double(peremennyaOne) * Double(peremennyaTwo)
                                    peremennyaOne = temp
                                    Result = Double(round(100000 * temp)/100000)
                                    isPresset = false
                                    label = NSNumber(value:Result).stringValue
                                    return;
                                case "+":
                                    peremennyaTwo = Double(label)!
                                    let temp : Double = Double(peremennyaOne) + Double(peremennyaTwo)
                                    peremennyaOne = temp
                                    Result = Double(round(100000 * temp)/100000)
                                    isPresset = false
                                    label = NSNumber(value:Result).stringValue
                                    return;
                                case "-":
                                    peremennyaTwo = Double(label)!
                                    let temp : Double = Double(peremennyaOne) - Double(peremennyaTwo)
                                    peremennyaOne = temp
                                    Result = Double(round(100000 * temp)/100000)
                                    isPresset = false
                                    label = NSNumber(value:Result).stringValue
                                    return;

                                default:
                                    return;
                                    
                                }
                            }
                            
                            

                        }
 
                    }, label: {Text("=").foregroundColor(Color(.white))})
                        .frame(width: 80, height: 80, alignment: .center)
                        .background(Color(.orange))
                        .clipShape(Circle())
                        .font(.system(size: 40))
                 }
            }.padding(.bottom, 30)
        }
        
        
 }
}
